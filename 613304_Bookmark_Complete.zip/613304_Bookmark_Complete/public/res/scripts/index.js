//*NOTE: All response from API Call will contain the following structure
/*


 {
 "status": "success",=====> will contain either 'success' or 'failure'
 "code": 200,======> status code Ex:404,500,200
 "data": {},====>>requested data
 "error": ""====>>if any errors
 }


 */

/*Service Factory for API Calls*/

/*

 create a service module using factory and 'ngResource' as dependency.

 This Service Should contain the configuration objects for the following APIs.

 1.To create a book
 =======================
 url:http://localhost:3000/book
 method:POST
 input data format:{name:'', description:'', price:'', category:''}

 2.To update a book
 =======================
 url:http://localhost:3000/book/id
 method:PUT
 input data format:{name:'', description:'', price:'', category:''}
 note:Here id is the id of book.

 3.To remove a book
 ========================
 url:http://localhost:3000/book/id
 method:DELETE
 note:Here id is the id of book.

 */
 var app = angular.module('Book',['ngResource']);
 
 app.factory('bookFactory', ['$resource', function ($resource) { 
 
    return $resource(
            'http://localhost:3000/products', 
            {"id":"@id"},//parameters
            {
                update: {
                      method: 'PUT', // To send the HTTP Put request when calling this custom update method.
					  url : 'http://localhost:3000/product/:id'
				},
				query: {
					interceptor: {
						response: function(response) {
							console.log(response.data.data);
							return response.data.data;
						}
					}
				},
				save: {
					method: 'POST',
					url: 'http://localhost:3000/product'
				},
				delete: {				
					method: 'DELETE',
					url: 'http://localhost:3000/product/:id'				
				}				
            }
		);
}]);
/*End of Service Factory*/

/*Create Angular Module*/
 
/*
 create a angular module in the name of 'Capstone' and put 'ui.router' as first dependency
 and the Service you have created above as a second dependency.
 */
	var capstone = angular.module('Capstone',['ui.router','Book']);
/*End Of Module Creation*/

/*App Route Config*/

/*
 create following states here for Capstone for navigation.using the state provider.

 1.book List
 ================
 *use the page public/pages/list.html
 *define your own controller for this state.

 2.book creation
 ===================
 *use the page public/pages/book.html
 *define your own controller for this state.


 3.book update
 =================
 *use the page public/pages/book.html
 *define your own controller for this state.

 use the Url route provider to set the default opening page.
 */

 capstone.config(['$stateProvider' , '$urlRouterProvider', function($stateProvider,$urlRouterProvider){
    $stateProvider
	.state('home',{
	    url:'/home',
		templateUrl : 'index.html',
		controller : 'bookListController'	
	})	
	.state('list',{
	    url:'/list',
		templateUrl : '../pages/list.html',
		controller : 'bookListController'	
	})
	.state('Create',{
	    url:'/create',
		templateUrl : '../pages/book.html',
		controller : 'bookCreateController'	
	})
	.state('Update',{
	    url:'/update',
		templateUrl : '../pages/book.html',
		controller : 'bookUpdateController'	
	});
	$urlRouterProvider.otherwise('list');
 
 }]);

/*End of Route Config*/


/*Book List Controller
 ==============================

 1.write your code to get list of Books using http provider in angularJs.

 URL: url:http://localhost:3000/Books
 method:GET

 2.after getting the list of Books, iterate the html elements to show all the Books as shown in requirement Document and
 iterate the Book list and get the unique category list.

 using this unique category list, display the categories in category filter section as shown in requirement Document .
 add "All Categories" as default in category filer section.

 3.write a function to filter the Books when a category is clicked in category filter section
 when "All categories" Clicked, show All Books.

 4.when edit button clicked, app should go to Book edit state.write a function to do that.

 5.when remove button clicked, a bootstrap modal should open to confirm the removal. upon confirmation,
 Book should be removed from the database. an alert message should be shown in green/Red upon successful/unsuccessful removal

 this alert messages should be hidden in 3 seconds. use timeout provider in angularJs for that.

 use the configured service object to make API call for removal.

* */

/* Start of bookListController */
capstone.controller('bookListController',['$scope','$state','bookFactory','$rootScope','$timeout',
		function($scope,$state,bookFactory,$rootScope,$timeout){
		
		var self = this;
		self.book= new bookFactory();          
		self.books={};
		$scope.tab = "All Categories";
		$scope.fiteredBooks = [];
		$scope.categories = [];
		var i = 0;
		$('#alertMsg').hide();
              
		self.fetchAllBooks = function()
		{
			self.books = bookFactory.query();
			 
			self.books.$promise.then(function(data){
				$scope.fiteredBooks = [];
				$scope.allBooks = [];
				$scope.categories = [];
				$scope.allBooks = data;
				$scope.fiteredBooks = angular.copy($scope.allBooks);
				angular.forEach($scope.fiteredBooks,function(key,value){
					$scope.categories[i] = key.category.charAt(0).toUpperCase() + key.category.slice(1);
					i++;			
				});			
			    /* * removing duplicates in category * */				
				$scope.uniqueCategory = [];
				for(var x = 0; x < $scope.categories.length; x++){					
					if($scope.uniqueCategory.indexOf($scope.categories[x]) == -1)
						$scope.uniqueCategory.push($scope.categories[x]);
				}
			});            
		};
		
		self.fetchAllBooks();
   
        /*Filtering the category based on the category selected */
		$scope.setCategories = function(newTab){
			$scope.searchText = "";
			$scope.fiteredBooks = [];	
			$scope.tab = newTab;
			if($scope.tab == "All Categories"){
				$scope.fiteredBooks = angular.copy($scope.allBooks);
			}else{
				angular.forEach($scope.allBooks,function(key,value){
					if($scope.tab.toLowerCase() == key.category.toLowerCase()){
						$scope.fiteredBooks.push(key);
					}		  
				})
			}      
		};
		
		$scope.addClick = function(){//Calling when "Add Book" button is clicked
			$rootScope.action = 'Add';
		}
		
		$scope.deleteBook = function(id,category){
		
			var modal_save_pup = $(".save_sub_pup");
				modal_save_pup.show();			
			$scope.deleteId = id;
		}
		
		$scope.updateBook = function(id){//Calling when Edit is clicked
		  $rootScope.action1 = 'Update';
		  $rootScope.updateId = id;		
		}
		
		$scope.confirmDelete = function(){
			var modal_save_pup = $(".save_sub_pup");
				modal_save_pup.hide();
			
			var book = bookFactory.get({id:$scope.deleteId}, function(response) {
        		book.$delete({id:$scope.deleteId}, function(resp){
						
					if(resp.status == 'success'){
					
						$timeout(function(){
							$('#alertMsg').hide();							
						},3000);
						$('#alertMsg').css('backgroundColor','#14BD8D');
						$('#alertMsg').css('border','#14BD8D');
						$scope.alertMessageDelete = "Successfully Deleted";
						self.fetchAllBooks();
						$('#alertMsg').show();
					}else{
						$timeout(function(){
							$('#alertMsg').hide();
						},3000);
						$('#alertMsg').css('backgroundColor','#FE4F4F');
						$('#alertMsg').css('border','#FE4F4F');
						$scope.alertMessageDelete = "Unsuccessfully Deleted";
					}
        		});				  
				  
        	});		
		};		

		$scope.isSet = function(tabNum){
		  return $scope.tab === tabNum;
		};
		
		$scope.confirmClose = function(){
			var modal_save_pup = $(".save_sub_pup");
				modal_save_pup.hide();	
		};
		var modal = document.getElementById('deletePopup');
		//modal.style.display = "block";
		
		window.onclick = function(event) {
		if (event.target == modal) {
        modal.style.display = "none";
		
    }
}

}]);
/*End of Book List Controller*/


/*Book Create Controller
 ================================
 1. write a function to save the Book.
 call this function when submit button in Book page clicked.

 an alert message should be shown in green/Red upon successful/unsuccessful creation of Book

 after successful creation of Book, app should navigate to list page(Book list state)
 use the configured service object to make API call for Creating Book.

 2.write a function to remove the form values in the Book page.
 call this function when cancel button in Book page clicked.

 * */
capstone.controller('bookCreateController',['$scope','$state','bookFactory','$rootScope','$timeout',
		function($scope,$state,bookFactory,$rootScope,$timeout){
		var self = this;
		self.book = new bookFactory();          
		self.books={};
		self.book._id = null;
		$scope.head = $rootScope.action;
		$('#alertMsgUpdate').hide();		
		
		  
		$scope.submitForm = function(){
			var data = {
			  "name" : $scope.name,
			  "description" : $scope.description,
			  "price" : $scope.price,
			  "category" : $scope.category			
			}			
			var login = bookFactory.save(data , function(data){
				if(data.status == "success"){
					$timeout(function(){
						$('#alertMsgUpdate').hide();
						$state.go('list');
					},3000);
					$('#alertMsgUpdate').css('backgroundColor','#14BD8D');
					$('#alertMsgUpdate').css('borderColor','#14BD8D');
					$scope.alertMessageUpdate = "Successfully Created";
					$('#alertMsgUpdate').show();
				}else{
					$timeout(function(){
						$('#alertMsgUpdate').hide();
						$state.go('list');
					},3000);
					$('#alertMsgUpdate').css('backgroundColor','#FE4F4F');
					$('#alertMsgUpdate').css('borderColor','#FE4F4F');
					$scope.alertMessageUpdate = "UnSuccessfully Created";
					$('#alertMsgUpdate').show();
				
				}			
			});			
		}
		/* clearing the form fields*/
		$scope.reset = function(){
              self.book= new bookFactory();
			  $scope.name = "";
			  $scope.description = "";
			  $scope.price = "";
			  $scope.category	= "";
              $scope.bookForm.$setPristine(); //reset Form			  
        };		
}]);
/*End of Book Create Controller*/


/*Book edit Controller
 ================================

 1.populate the details of the Book which is going to be updated into form using 2 way binding.

 2. write a function to update the Book.
 call this function when submit button in Book page clicked.

 an alert message should be shown in green/Red upon successful/unsuccessful update of Book

 after successful update of Book, app should navigate to list page(Book list state)

 3.write a function to remove the form values in the Book page.
 call this function when cancel button in Book page clicked.

 * */
capstone.controller('bookUpdateController',['$scope','$state','bookFactory','$rootScope','$timeout',
		function($scope,$state,bookFactory,$rootScope,$timeout){
		
		$scope.head = $rootScope.action;
		var data = {};
		var self = this;
		self.book = new bookFactory();
		data = $rootScope.updateId;		
		$scope.name = data.name;
		$scope.description = data.description;
		$scope.price = data.price;
		$scope.category	= data.category;
		
		
		$('#alertMsgUpdate').hide();
		
		$scope.submitForm = function(){   
			var updatedData = {
				"name" : $scope.name,
				"description" : $scope.description,
				"price" : $scope.price,
				"category" : $scope.category
		   }
    		var sucess = bookFactory.update({id:data._id},updatedData, function(resp){
						if(resp.status == 'success'){
							$timeout(function(){
								$('#alertMsgUpdate').hide();
								$state.go('list');
							},3000);
							$('#alertMsgUpdate').css('backgroundColor','#14BD8D');
							$('#alertMsgUpdate').css('borderColor','#14BD8D');
							$scope.alertMessageUpdate = "Successfully Updated";
							$('#alertMsgUpdate').show();
						}	else{
								$timeout(function(){
									$('#alertMsgUpdate').hide();
									$state.go('list');
								},3000);
								$('#alertMsgUpdate').css('backgroundColor','#FE4F4F');
								$('#alertMsgUpdate').css('borderColor','#FE4F4F');
								$scope.alertMessageUpdate = "UnSuccessfully Created";
								$('#alertMsgUpdate').show();
							}
        		  });
    		  
        };
		
		$scope.reset = function(){
              self.book= new bookFactory();
			  $scope.name = "";
			  $scope.description = "";
			  $scope.price = "";
			  $scope.category	= "";
              $scope.bookForm.$setPristine(); //reset Form			  
        };		
}]);
/*End of Book edit Controller*/